# ECOLIT HR Portal

Ecolit Ceiling Solutions kompaniyasining HR portali (statik sayt, GitHub Pages uchun).

Bo'limlar: Bosh sahifa, Hodimlar bazasi, Bo'sh ish o'rinlari, Onlayn ariza berish, Test topshirish, Kompaniya haqida, HR yangiliklari, Mening profilim, Sozlamalar.

Eslatma: arizalar va test natijalari foydalanuvchi brauzerida (localStorage) saqlanadi — server/baza yo'q.
